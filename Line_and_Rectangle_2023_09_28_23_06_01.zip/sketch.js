function setup() {
  //creates canvas 720x400 pixels big
  createCanvas(720,400);
}

function draw() {
  //sets the background to the color red and turns off the fill color
  background(0,255,0);
  noFill();
  
  stroke(255);
  point(width * 0.5, height * 0.5);
  point(width * 0.5, height * 0.25);
  
  stroke(255,255,255);
  line(200,height * 0.6, width, height * 0.33);
  
  stroke(255,153,0);
  rect(width * 0.115, height*0.1, width * 0.115, height*0.1);
  
 
  
}