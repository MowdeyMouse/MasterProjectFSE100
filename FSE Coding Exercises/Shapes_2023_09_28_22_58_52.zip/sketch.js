function setup() {
  createCanvas(720, 400);
  background(0);
  noStroke();
  
  fill(204);
  triangle(18,180,18,360,81,360);
  
  fill(102);
  rect(81,82,63,64);
  
  fill(204);
  quad(103,103,206,103,206,360,144,360);
  
  fill(255);
  ellipse(252,252,120,100);
  
  fill(204);
  triangle(0,18,351,360,288,360);
  
  fill(255);
  arc(479,300,280,400,PI,TWO_PI);
  
}