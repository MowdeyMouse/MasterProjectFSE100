function setup() {
  createCanvas(720, 400);
  background(255,255,0);
  strokeWeight(2);
}

function draw() {
  if (mouseIsPressed) {
    stroke(255);
    strokeWeight(20);
  } else {
    stroke(237, 34, 93);
    strokeWeight(1);
  }
  line(mouseX - 66, mouseY, mouseX + 66, mouseY);
  line(mouseX, mouseY - 66, mouseX, mouseY + 66);
}
