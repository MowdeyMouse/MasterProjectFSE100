function setup() {
  createCanvas(720, 400);
  background(0);
  stroke(153);
  strokeWeight(4);
  strokeCap(SQUARE);

  let a = 100;
  let b = 180;
  let c = 100;

  line(a, b, a + c, b);
  line(a, b + 10, a + c, b + 10);
  line(a, b + 20, a + c, b + 20);
  line(a, b + 30, a + c, b + 30);

  a = a + c;
  b = height - a;

  line(a, b, a + c, b);
  line(a, b + 30, a + c, b + 10);
  line(a, b + 20, a + c, b + 20);
  line(a, b + 30, a + c, b + 30);

  a = a + c;
  b = height - a;

  line(a, b, a + c, b);
  line(a, b + 10, a + c, b + 10);
  line(a, b + 30, a + c, b + 20);
  line(a, b + 30, a + c, b + 30);
}
